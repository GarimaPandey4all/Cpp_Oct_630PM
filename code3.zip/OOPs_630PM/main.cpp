#include <iostream>

using namespace std;

/*
    1. Function definition inside the class
    2. Function definition outside the class
*/

//Function definition inside the class
class Human
{
public:
    void showData()
    {
        cout<<"This is function inside the class example";
    }
};

int main()
{
    Human Aman;
    Aman.showData();

    return 0;
}
