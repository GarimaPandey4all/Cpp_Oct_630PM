#include <iostream>

using namespace std;

//Function definition outside the class

class Human
{
public: // 2
    void showData(); // 3
};

void Human :: showData() // 4
{
    cout<<"This is function outside the class";
}

int main()
{
    Human Aman; // 1
    Aman.showData(); // 2

    return 0;
}
