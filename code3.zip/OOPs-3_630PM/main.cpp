#include <iostream>

using namespace std;

/*
    Access Specifiers:

    1. public
    2. private(by default)
    3. protected // inheritance

*/

class varAssign
{
public:
    int x;
//private:
    int y;
};

int main()
{
    varAssign obj;
    obj.x = 10;
    obj.y = 10;

    cout<<"X is:"<<obj.x<<endl;
    cout<<"Y is:"<<obj.y;

    return 0;
}
