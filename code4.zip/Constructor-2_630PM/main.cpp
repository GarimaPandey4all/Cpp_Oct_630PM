#include <iostream>

using namespace std;

class Myclass
{
public:

    Myclass();
};

Myclass :: Myclass()
{
   cout<<"This is constructor example";
}

int main()
{
    Myclass obj;

    return 0;
}
