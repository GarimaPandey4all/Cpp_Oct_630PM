#include <iostream>

using namespace std;

class Car
{
public:
    string model;
    string brand;
    string year;

    Car(string x, string y, string z) // Parameterized Constructor
    {
        model = x;
        brand = y;
        year = z;
    }

    void getData()
    {
        cout<<"Model is:"<<model<<endl;
        cout<<"brand is:"<<brand<<endl;
        cout<<"year is:"<<year<<endl;
    }

};

int main()
{
    Car obj("C5", "Maruti Suzuki", "2020");

    obj.getData();

    return 0;
}
