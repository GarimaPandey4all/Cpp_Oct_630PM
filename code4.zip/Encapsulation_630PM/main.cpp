#include <iostream>

using namespace std;

//Encapsulation: Class is an example of encapsulation.
//It is a process in which it wrapping up data members and member functions
// together in a single unit.

class Encapsulation
{
public:
    int x;

    void display()
    {
        cout<<"x is:"<<x<<endl;
    }
};

int main()
{
    Encapsulation obj;
    obj.x = 20;
    obj.display();

    return 0;
}
