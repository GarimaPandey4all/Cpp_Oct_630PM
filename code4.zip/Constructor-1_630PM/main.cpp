#include <iostream>

using namespace std;

class Myclass
{
public:

    //Special Function: Constructor
    //Constructor: It is a special type of function because both class name and function name are same.
    //It is used to initialize the instance variables.
    //No need to instantiate/called the constructor. It is called automatically when object is created.

    Myclass()
    {
        cout<<"This is constructor example";
    }
};


int main()
{
    Myclass obj;

    return 0;
}
