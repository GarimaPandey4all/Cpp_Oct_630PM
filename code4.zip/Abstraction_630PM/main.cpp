#include <iostream>

using namespace std;

class Abstraction
{
private:
    int a, b;

public:
    void setData(int x, int y) //setter
    {
        a = x;
        b = y;
    }

     void getData() // getter
     {
         cout<<"Addition is:"<<(a + b)<<endl;
     }
};


int main()
{
    Abstraction obj;

    obj.setData(10, 20);
    obj.getData();

    return 0;
}
