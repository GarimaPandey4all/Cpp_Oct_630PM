#include <iostream>

using namespace std;

class Calculator
{
public:
    int a, b;

    void add();
    void sub();
    void mul();
    void div();
};

void Calculator :: add()
    {
        cout<<"Addition:"<<endl;
        cout<<"Enter any value for a and b:";
        cin>>a>>b;

        cout<<"Addition is:"<<a + b<<endl;
    }

void Calculator :: sub()
    {
        cout<<"Subtraction:"<<endl;
        cout<<"Enter any value for a and b:";
        cin>>a>>b;

        cout<<"Subtraction is:"<<a - b<<endl;
    }

void Calculator :: mul()
    {
        cout<<"Multiplication:"<<endl;
        cout<<"Enter any value for a and b:";
        cin>>a>>b;

        cout<<"Multiplication is:"<<a * b<<endl;
    }

void Calculator :: div()
    {
        cout<<"Division:"<<endl;
        cout<<"Enter any value for a and b:";
        cin>>a>>b;

        cout<<"Division is:"<<a / b<<endl;
    }

int main()
{
    Calculator obj;

    obj.add();
    obj.sub();
    obj.mul();
    obj.div();

    return 0;
}
