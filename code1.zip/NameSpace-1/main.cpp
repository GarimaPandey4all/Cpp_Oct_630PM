#include <iostream>

using namespace std;

namespace first
{
    int value = 500;
}

//Global Variable
int value = 700;

int main()
{
    //int value = 200; // local variable

    cout<<"Value is:"<<value<<endl;

    cout<<"Value is:"<<first::value<<endl;

    return 0;
}
