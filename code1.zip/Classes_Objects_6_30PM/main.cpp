#include <iostream>

using namespace std;

//Class is a combination of data members and member functions.

class HelloWorld
{
    public: // Access Specifier
    void showData()
    {
        cout<<"Hello World\n"<<endl;
    }
};

int main()
{
    HelloWorld obj; // Instance of a class
    HelloWorld obj1;

    obj.showData(); // Calling
    obj1.showData();

    return 0;
}
