#include <iostream> // input / output stream

//using namespace std;

int main()
{
    int a, b;

    /*
    cout<<"Hello World"<<endl; // endl - new line
    cout<<"Hello World";
    */

    std::cout<<"Enter any value for a and b:";
    std::cin>>a>>b;

    int c = a+b;

    std::cout<<"Addition is:"<<c<<std::endl;

    //cout<<"Addition is:"<<a+b<<endl;

    return 0;
}
