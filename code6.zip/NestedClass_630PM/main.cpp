#include <iostream>

using namespace std;

//Nested Class
class A
{
public:
    class B
    {
    public:
        void ShowData()
        {
            cout<<"Hello World";
        }
    };
};


int main()
{
    A :: B obj;
    obj.ShowData();

    return 0;
}
