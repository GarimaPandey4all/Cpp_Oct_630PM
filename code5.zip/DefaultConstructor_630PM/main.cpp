#include <iostream>

using namespace std;

class DC
{
public:
    int a, b;

    DC()
    {
        a = 10;
        b = 20;
    }

    void ShowData()
    {
        cout<<"A is:"<<a<<endl;
        cout<<"B is:"<<b<<endl;
    }
};


int main()
{
    DC obj;
    obj.ShowData();

    return 0;
}
