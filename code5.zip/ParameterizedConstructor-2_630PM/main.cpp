#include <iostream>

using namespace std;

class PC
{
public:
    int a, b;

    PC(int x, int y)
    {
        a = x;
        b = y;
    }

    void ShowData()
    {
        cout<<"A is:"<<a<<endl;
        cout<<"B is:"<<b<<endl;
    }
};


int main()
{
    PC obj(10, 20);
    obj.ShowData();

    return 0;
}
