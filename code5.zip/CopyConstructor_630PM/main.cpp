#include <iostream>

using namespace std;

class PC
{
public:
    int a;

    PC(int x) // PC
    {
        a = x; // a = 10
    }

    PC(PC &t) // Copy Constructor
    {
        a = t.a;
    }
};


int main()
{
    PC obj1(10); // calling parameterized constructor
    PC obj2(obj1); // calling copy constructor

    cout<<"A of obj2 is:"<<obj2.a;

    return 0;
}
