#include <iostream>

using namespace std;

/*
    Inheritance: Code Reusability

    Parent - Child Relationship

    Base Class - Derived Class

    Inheritance has five types:

    1. Single Inheritance
    2. Multiple Inheritance
    3. Multilevel Inheritance
    4. Hierarchical Inheritance
    5. Hybrid Inheritance
*/

//1. Single Inheritance

class Human
{
public:
    Human()
    {
        cout<<"This is Parent Class"<<endl;
    }
};

class Person : public Human // Human-Parent, Person-Child // Inheritance
{
public:
    Person()
    {
        cout<<"This is Child Class"<<endl;
    }
};

int main()
{
    Person obj;

    return 0;
}
