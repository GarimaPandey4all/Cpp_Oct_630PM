#include <stdio.h>
#include <stdlib.h>

/*
    argc: Argument Count = 6
    argv: Argument Vector

    Input: brain 3 5 10 aman

    main(program name, brain, 3, 5, 10, aman)

    argv[0] = program name
    argv[1] = brain
    argv[2] = 3
    argv[3] = 5
    argv[4] = 10
    argv[5] = aman
*/

int main(int argc, char *argv[])
{
    int i;

    for(i = 0; i < argc; i++)
    {
        printf("Arguments are:%s\n", argv[i]);
    }

    printf("Argument count is: %d", argc);

    getch();

    return 0;
}
