#include <iostream>

using namespace std;

class Shape
{
public:
    virtual void shape() = 0; // Pure Virtual Function
};

class Circle : public Shape
{
public:
    void shape()
    {
        cout<<"Circle Shape"<<endl;
    }
};


class Square : public Shape
{
public:
    void shape()
    {
        cout<<"Square Shape"<<endl;
    }
};

int main()
{
    Circle obj;
    obj.shape();

    Square obj1;
    obj1.shape();

    return 0;
}
