#include <iostream>

using namespace std;

class Shape
{
public:
    virtual void shape() // Override this function
    {
        cout<<"Shape of Parent Class"<<endl;
    }
};

class Circle : public Shape
{
public:
    void shape()// Virtual function must be redefine in derived class.
    {
        cout<<"Shape of Circle"<<endl;
    }
};

int main()
{
    //Pointer variable always points to pointer type variables
    Shape *pobj; //parent class's pointer object
    Circle obj2;

    pobj = &obj2; // assigning the circle class's object to parent's class object

    //Virtual function, bind at runtime: runtime polymorphism

    pobj->shape();

    return 0;
}
