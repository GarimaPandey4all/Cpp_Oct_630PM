#include <iostream>

using namespace std;

class Student
{
private:
    int rollno; // instance variable or data member
    static int marks; // static member variable / class member variable

public:

    void setData(int r)
    {
        rollno = r;
    }

    void getData()
    {
        cout<<"Roll no is:"<<rollno<<endl;
        cout<<"Marks is:"<<marks<<endl;
    }
};

int Student :: marks = 557; // static variable defined

int main()
{
    Student obj;
    Student obj1;
    obj.setData(12);
    obj.getData();
    obj1.setData(15);
    obj1.getData();

    return 0;
}
