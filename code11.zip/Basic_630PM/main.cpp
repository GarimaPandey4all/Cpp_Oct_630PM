#include <iostream>

using namespace std;

int main()
{
//    int a = 20, b = 0;
//
//    cout<<"Division is:"<<a/b;

    int ch = 45.678;

    cout<<"ch is:"<<ch<<endl;

    return 0;
}
