#include <iostream>

using namespace std;

/*
    Static Member Variable

    1. Declared inside the class body
    2. also known as class member variable
    3. They must be defined outside the class
    4. static member variable does not belong to any object, but to the whole class.
    5. There will be only one copy of static member variable for the whole class
    6. Any object can use the same copy of class variable
    7. They can also be used with class name
*/

class Student
{
private:
    int rollno; // instance variable or data member
    static int marks; // static member variable / class member variable

public:

    void setData(int r)
    {
        rollno = r;
    }

    void getData()
    {
        cout<<"Roll no is:"<<rollno<<endl;
        cout<<"Marks is:"<<marks<<endl;
    }
};

int Student :: marks = 525; // static variable defined

int main()
{
    Student obj;
    obj.setData(12);
    obj.getData();

    return 0;
}
