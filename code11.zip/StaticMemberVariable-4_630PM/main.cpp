#include <iostream>

using namespace std;

class Demo
{
public:
    static void func()
    {
        cout<<"This is static function block"<<endl;
    }
};

int main()
{
    Demo::func();// calling static member function directly with the class name

    return 0;
}
