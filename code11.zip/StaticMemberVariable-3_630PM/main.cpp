#include <iostream>

using namespace std;

class Counter
{
public:
    void updateCount()
    {
        static int count; // static int count = 0;
        cout<<"Count is:"<<count++<<endl;
    }
};

int main()
{
    Counter obj;
    for(int i = 0; i < 5; i++)
        obj.updateCount();

    return 0;
}
