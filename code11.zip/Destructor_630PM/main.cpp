#include <iostream>

//Destructor: delete the object, it is called automatically

using namespace std;

class HelloWorld
{
public:
    //constructor
    HelloWorld()
    {
        cout<<"Constructor"<<endl;
    }

    //destructor - ~
    ~HelloWorld()
    {
        cout<<"Destructor"<<endl;
    }

//    ~HelloWorld()
//    {
//        cout<<"Destructor"<<endl;
//    }

    void display()
    {
        cout<<"Hello World"<<endl;
    }
};

int main()
{
    HelloWorld obj;
    obj.display();

    return 0;
}
