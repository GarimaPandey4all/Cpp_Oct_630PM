#include <stdio.h>
#include <stdlib.h>

int main()
{
   int roll;
   char grade;
   float per;

   printf("Enter Your Grade:\n");
   scanf("%c",&grade);

   printf("Enter Your Roll-Number:\n");
   scanf("%d",&roll);

   printf("Enter Your Percentage:\n");
   scanf("%f",&per);

   printf("Your Roll-Number Is:%d\n",roll);

   printf("Your Percentage Is:%f\n",per);

   printf("Your Grade Is:%c\n",grade);

    return 0;
}

