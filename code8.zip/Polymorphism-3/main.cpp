#include <iostream>

using namespace std;

class Complex
{
private:
    int real;
    int imag;

public:
    Complex(int r, int i)
    {
        real = r;
        imag = i;
    }
};

int main()
{
    Complex obj(4, 7);// 4 + i7
    Complex obj2(2, 3); // 2 + i3

    //Complex obj3; // error

    //obj3 = obj + obj2; // error  // obj.add(obj2)

    return 0;
}
