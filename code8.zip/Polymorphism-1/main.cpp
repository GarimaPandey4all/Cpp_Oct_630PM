#include <iostream>

using namespace std;

/*
    Polymorphism: poly and morphism

    poly -  many

    morphism - forms

    person : student, son, father, trainer, employee etc...

    polymorphism: Two types of polymorphism

    1. Compile time
        a) Function Overloading
        b) Operator Overloading

    2. Runtime
        a) Overriding: Virtual Functions

*/

//Function Overloading

class Func_Overloading
{
public:
     void func(int a)
     {
         cout<<"a is:"<<a<<endl;
     }

     void func(int x, int y)
     {
         cout<<"x is:"<<x<<endl;
         cout<<"y is:"<<y<<endl;
     }

     void func(int x, int y, int z)
     {
         cout<<"x is:"<<x<<endl;
         cout<<"y is:"<<y<<endl;
         cout<<"z is:"<<z<<endl;
     }

     void func(float z)
     {
         cout<<"z is:"<<z<<endl;
     }
};

int main()
{
    Func_Overloading obj;

    obj.func(10);
    //obj.func();// error
    obj.func(10, 20);
    obj.func(30, 60, 90);
    obj.func(50.67f);

    return 0;
}
