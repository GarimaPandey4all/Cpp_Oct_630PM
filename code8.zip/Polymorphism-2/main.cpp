#include <iostream>

using namespace std;

class Calculator
{
public:

        void Add(int a, int b)
        {
            cout<<"Addition of integer values:"<<(a + b)<<endl;
        }

        void Add(float x, float y)
        {
            cout<<"Addition of floating values:"<<(x + y)<<endl;
        }

        void Sub(int a, int b)
        {
            cout<<"Subtraction of integer values:"<<(a - b)<<endl;
        }

        void Sub(float x, float y)
        {
            cout<<"Subtraction of floating values:"<<(x - y)<<endl;
        }

        void Mul(int a, int b)
        {
            cout<<"Multiplication of integer values:"<<(a * b)<<endl;
        }

        void Mul(float x, float y)
        {
            cout<<"Multiplication of floating values:"<<(x * y)<<endl;
        }

        void Div(int a, int b)
        {
            cout<<"Division of integer values:"<<(a / b)<<endl;
        }

        void Div(float x, float y)
        {
            cout<<"Division of floating values:"<<(x / y)<<endl;
        }
};

int main()
{
    Calculator obj;

    obj.Add(10, 20);
    obj.Add(10.67f, 20.78f);


    obj.Sub(10, 20);
    obj.Sub(10.67f, 20.78f);


    obj.Mul(10, 20);
    obj.Mul(10.67f, 20.78f);


    obj.Div(10, 20);
    obj.Div(10.67f, 20.78f);

    return 0;
}
