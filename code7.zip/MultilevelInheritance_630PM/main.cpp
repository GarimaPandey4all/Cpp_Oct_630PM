#include <iostream>

using namespace std;

class Parent
{
public:
    int parent;
};

class Child1 : public Parent
{
public:
    int child1;
};

class Child2 : public Child1
{
public:
    int child2;
};

int main()
{
    Child2 obj;

    obj.child2 = 20;
    obj.child1 = 30;
    obj.parent = 50;

    cout<<"Child-2 is:"<<obj.child2<<endl;
    cout<<"Child-1 is:"<<obj.child1<<endl;
    cout<<"Parent is:"<<obj.parent<<endl;

    return 0;
}
