#include <iostream>

using namespace std;

class VarAssign
{
private:
    int a, b;

public:
    VarAssign(int a, int b)
    {
        this.a = a;
        this.b = b;
    }
};

int main()
{
    VarAssign obj(10, 20);

    return 0;
}
