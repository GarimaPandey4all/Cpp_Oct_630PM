#include <iostream>

using namespace std;

namespace first
{
    int value = 500;
}

namespace dataType
{
    int value = 300;

    void showData()
    {
        cout<<"Hello World"<<endl;
    }
}

//Global Variable
int value = 700;

int main()
{
    //int value = 200; // local variable

    cout<<"Value is:"<<value<<endl;

    cout<<"Value is:"<<first::value<<endl;

    cout<<"Value is:"<<dataType::value<<endl;

    dataType::showData();

    //dataType::showData();

    return 0;
}
